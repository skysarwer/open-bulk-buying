<?php
/**
 * Plugin settings and site-local maintenance actions for the Settings screen.
 *
 * @package Open_Bulk_Buying
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OPENBB_REST_Settings extends OPENBB_REST_Controller {

	const DELETE_CONFIRMATION = 'DELETE ALL DATA';

	public function register_routes(): void {
		$can_manage = static function () {
			return self::authorize( 'openbb_manage_settings' );
		};

		register_rest_route(
			self::API_NAMESPACE,
			'/settings',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_settings' ),
					'permission_callback' => $can_manage,
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_settings' ),
					'permission_callback' => $can_manage,
					'args'                => array(
						'test_mode'      => array( 'type' => 'boolean' ),
						// Write-only: '' keeps the saved secret.
						'captcha_secret' => array(
							'type'      => 'string',
							'maxLength' => 200,
							'pattern'   => '^[A-Za-z0-9_.\-]*$',
						),
						'general'        => array(
							'type'                 => 'object',
							'additionalProperties' => false,
							'required'             => array( 'allow_signups', 'allow_login_codes', 'captcha_provider', 'turnstile_site_key', 'require_member_approval', 'membership_fee_type', 'membership_fee_amount', 'membership_fee_order_interval' ),
							'properties'           => array(
								'allow_signups'                 => array( 'type' => 'boolean' ),
								'allow_login_codes'             => array( 'type' => 'boolean' ),
								'captcha_provider'              => array(
									'type' => 'string',
									'enum' => OPENBB_Captcha::PROVIDERS,
								),
								'turnstile_site_key'            => array(
									'type'      => 'string',
									'maxLength' => 200,
									'pattern'   => '^[A-Za-z0-9_.\-]*$',
								),
								'require_member_approval'       => array( 'type' => 'boolean' ),
								'membership_fee_type'           => array(
									'type' => 'string',
									'enum' => array( 'one_time', 'recurring' ),
								),
								'membership_fee_amount'         => array(
									'type'    => 'integer',
									'minimum' => 0,
									'maximum' => 9007199254740991,
								),
								'membership_fee_order_interval' => array(
									'type'    => 'integer',
									'minimum' => 1,
									'maximum' => 9007199254740991,
								),
								'default_prep_method'           => array(
									'type' => 'string',
									'enum' => OPENBB_Cycle_Preparation::METHODS,
								),
								'document_paper_size'           => array(
									'type' => 'string',
									'enum' => OPENBB_Documents::PAPER_SIZES,
								),
								'email_staff_note'              => array( 'type' => 'boolean' ),
							),
						),
					),
				),
			)
		);

		register_rest_route(
			self::API_NAMESPACE,
			'/settings/demo-data',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'populate_demo_data' ),
				'permission_callback' => $can_manage,
			)
		);

		$can_manage_fields = static function () {
			return self::authorize( 'openbb_manage_profile_fields' );
		};

		$can_manage_rules = static function () {
			return self::authorize( 'openbb_manage_rules' );
		};
		$rule_content = array(
			'type'     => 'array',
			'required' => true,
			'items'    => array(
				'type'                 => 'object',
				'required'             => array( 'default' ),
				'properties'           => array( 'default' => array( 'type' => 'string' ) ),
				'additionalProperties' => array( 'type' => 'string' ),
			),
		);
		register_rest_route(
			self::API_NAMESPACE,
			'/settings/rules',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_rules' ),
					'permission_callback' => $can_manage_rules,
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'save_rules' ),
					'permission_callback' => $can_manage_rules,
					'args'                => array(
						'content'  => $rule_content,
						'revision' => array( 'type' => 'string', 'required' => true ),
					),
				),
			)
		);
		foreach ( array( 'publish', 'discard' ) as $action ) {
			register_rest_route(
				self::API_NAMESPACE,
				'/settings/rules/' . $action,
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'publish' === $action ? 'publish_rules' : 'discard_rules' ),
					'permission_callback' => $can_manage_rules,
					'args'                => array_merge(
						array( 'revision' => array( 'type' => 'string', 'required' => true ) ),
						'publish' === $action ? array( 'requires_reacceptance' => array( 'type' => 'boolean', 'required' => true ) ) : array()
					),
				)
			);
		}

		register_rest_route(
			self::API_NAMESPACE,
			'/settings/profile-fields',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_profile_fields' ),
					'permission_callback' => $can_manage_fields,
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_profile_fields' ),
					'permission_callback' => $can_manage_fields,
					'args'                => array(
						'revision' => array(
							'type'     => 'integer',
							'minimum'  => 0,
							'required' => true,
						),
						'fields'   => array(
							'type'     => 'array',
							'items'    => array( 'type' => 'object' ),
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			self::API_NAMESPACE,
			'/settings/profile-fields/(?P<key>[a-z][a-z0-9_]{0,39})/purge',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'purge_profile_field' ),
				'permission_callback' => $can_manage_fields,
				'args'                => array(
					'confirmation' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		$can_manage_access = static function () {
			return self::authorize( 'openbb_manage_access' );
		};
		$role_revision     = array(
			'revision' => array(
				'description' => __( 'The roles revision the change is based on; \'\' while the roles are the defaults.', 'open-bulk-buying' ),
				'type'        => 'string',
				'required'    => true,
			),
		);
		$role_data         = $role_revision + array(
			'label' => array(
				'type'     => 'string',
				'required' => true,
			),
			'caps'  => array(
				'type'     => 'array',
				'items'    => array( 'type' => 'string' ),
				'required' => true,
			),
		);
		register_rest_route(
			self::API_NAMESPACE,
			'/settings/roles',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_roles' ),
					'permission_callback' => $can_manage_access,
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_role' ),
					'permission_callback' => $can_manage_access,
					'args'                => $role_data,
				),
			)
		);
		register_rest_route(
			self::API_NAMESPACE,
			'/settings/roles/reset-all',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'reset_roles' ),
				'permission_callback' => $can_manage_access,
				'args'                => $role_revision,
			)
		);
		register_rest_route(
			self::API_NAMESPACE,
			'/settings/roles/(?P<key>[a-z0-9_]+)',
			array(
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_role' ),
					'permission_callback' => $can_manage_access,
					'args'                => $role_data,
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_role' ),
					'permission_callback' => $can_manage_access,
					'args'                => $role_revision,
				),
			)
		);
		register_rest_route(
			self::API_NAMESPACE,
			'/settings/roles/(?P<key>[a-z0-9_]+)/reset',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'reset_role' ),
				'permission_callback' => $can_manage_access,
				'args'                => $role_revision,
			)
		);

		register_rest_route(
			self::API_NAMESPACE,
			'/settings/delete-all-data',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'delete_all_data' ),
				'permission_callback' => static function () {
					return self::authorize( 'manage_options' );
				},
				'args'                => array(
					'confirmation' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
	}

	public function get_settings(): WP_REST_Response {
		return rest_ensure_response( self::prepare_settings() );
	}

	public function get_rules(): WP_REST_Response {
		$versions = array_map(
			static function ( OPENBB_Rules_Version $version ): array {
				$author = get_userdata( $version->published_by );
				return array(
					'id'                    => $version->id,
					'content'               => $version->content,
					'published_at'          => mysql_to_rfc3339( $version->published_at ),
					'published_by'          => $author ? $author->display_name : __( 'Deleted user', 'open-bulk-buying' ),
					'requires_reacceptance' => $version->requires_reacceptance,
				);
			},
			OPENBB_Rules::get_versions()
		);

		return rest_ensure_response(
			array(
				'draft'       => OPENBB_Rules::get_draft(),
				'revision'    => self::rules_revision(),
				'unpublished' => OPENBB_Rules::has_unpublished_changes(),
				'versions'    => $versions,
			)
		);
	}

	private static function rules_revision(): string {
		$latest = OPENBB_Rules::get_latest();
		return md5( OPENBB_Rules::hash_content( OPENBB_Rules::get_draft() ) . ':' . ( $latest ? $latest->id : 0 ) );
	}

	private static function check_rules_revision( WP_REST_Request $request ): ?WP_Error {
		if ( self::rules_revision() !== $request['revision'] ) {
			return new WP_Error( 'openbb_rules_stale', __( 'The rules changed since you loaded them. Reload the rules before saving.', 'open-bulk-buying' ), array( 'status' => 409 ) );
		}
		return null;
	}

	public function save_rules( WP_REST_Request $request ) {
		$error = self::check_rules_revision( $request );
		if ( $error ) {
			return $error;
		}
		if ( ! OPENBB_Rules::save_draft( $request['content'] ) ) {
			return new WP_Error( 'openbb_rules_save_failed', __( 'The draft could not be saved.', 'open-bulk-buying' ), array( 'status' => 500 ) );
		}
		return $this->get_rules();
	}

	public function publish_rules( WP_REST_Request $request ) {
		$error = self::check_rules_revision( $request );
		if ( $error ) {
			return $error;
		}
		$result = OPENBB_Rules::publish( $request['requires_reacceptance'], get_current_user_id() );
		return is_wp_error( $result ) ? self::with_status( $result, 'openbb_rules_empty' === $result->get_error_code() ? 400 : 500 ) : $this->get_rules();
	}

	public function discard_rules( WP_REST_Request $request ) {
		$error = self::check_rules_revision( $request );
		if ( $error ) {
			return $error;
		}
		if ( ! OPENBB_Rules::discard_draft() ) {
			return new WP_Error( 'openbb_rules_discard_failed', __( 'The draft could not be discarded.', 'open-bulk-buying' ), array( 'status' => 500 ) );
		}
		return $this->get_rules();
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_settings( WP_REST_Request $request ) {
		$secret = trim( (string) $request->get_param( 'captcha_secret' ) );

		if ( $request->has_param( 'general' ) ) {
			$general = array_merge( OPENBB_Settings::get_general(), $request->get_param( 'general' ) );
			$general['turnstile_site_key'] = trim( (string) $general['turnstile_site_key'] );
			if ( OPENBB_Captcha::PROVIDER_TURNSTILE === $general['captcha_provider'] ) {
				$errors = array();
				if ( '' === $general['turnstile_site_key'] ) {
					$errors['turnstile_site_key'] = __( 'Enter the Turnstile site key.', 'open-bulk-buying' );
				}
				if ( '' === $secret && '' === OPENBB_Captcha::secret() ) {
					$errors['captcha_secret'] = __( 'Enter the Turnstile secret key.', 'open-bulk-buying' );
				}
				if ( $errors ) {
					return new WP_Error(
						'openbb_captcha_incomplete',
						implode( ' ', $errors ),
						array(
							'status' => 400,
							'errors' => $errors,
						)
					);
				}
			}
		}

		if ( '' !== $secret && ! OPENBB_Captcha::secret_from_constant() && OPENBB_Captcha::secret() !== $secret
			&& ! update_option( OPENBB_Captcha::SECRET_OPTION, $secret, false ) ) {
			return new WP_Error( 'openbb_settings_save_failed', __( 'The settings could not be saved.', 'open-bulk-buying' ), array( 'status' => 500 ) );
		}

		if ( isset( $general ) ) {
			if ( get_option( OPENBB_Settings::GENERAL_OPTION, array() ) != $general
				&& ! update_option( OPENBB_Settings::GENERAL_OPTION, $general, false ) ) {
				return new WP_Error( 'openbb_settings_save_failed', __( 'The settings could not be saved.', 'open-bulk-buying' ), array( 'status' => 500 ) );
			}
		}

		if ( $request->has_param( 'test_mode' ) ) {
			$enabled = (bool) $request->get_param( 'test_mode' );
			$saved   = OPENBB_Maintenance::is_test_mode() === $enabled
				|| update_option( OPENBB_Maintenance::TEST_MODE_OPTION, $enabled, false );
			if ( ! $saved ) {
				return new WP_Error( 'openbb_settings_save_failed', __( 'The settings could not be saved.', 'open-bulk-buying' ), array( 'status' => 500 ) );
			}
		}

		return rest_ensure_response( self::prepare_settings() );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public function populate_demo_data() {
		$result = OPENBB_Maintenance::populate_test_data();
		if ( is_wp_error( $result ) ) {
			$conflict = in_array( $result->get_error_code(), array( 'openbb_test_mode_disabled', 'openbb_demo_product_conflict', 'openbb_demo_term_conflict' ), true );
			return self::with_status( $result, $conflict ? 409 : 500 );
		}

		return rest_ensure_response( array( 'populated' => true ) );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_all_data( WP_REST_Request $request ) {
		if ( self::DELETE_CONFIRMATION !== $request->get_param( 'confirmation' ) ) {
			return self::invalid(
				/* translators: %s: the confirmation phrase. */
				sprintf( __( 'Type %s to confirm.', 'open-bulk-buying' ), self::DELETE_CONFIRMATION ),
				'openbb_delete_unconfirmed'
			);
		}

		$result = OPENBB_Maintenance::delete_all_site_data();
		if ( is_wp_error( $result ) ) {
			return self::with_status( $result, 500 );
		}

		return rest_ensure_response( array( 'deleted' => true ) );
	}

	public function get_roles(): WP_REST_Response {
		return rest_ensure_response( OPENBB_Roles::describe() );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_role( WP_REST_Request $request ) {
		return self::roles_response( OPENBB_Roles::create_role( self::role_data( $request ), (string) $request['revision'] ), 201 );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_role( WP_REST_Request $request ) {
		return self::roles_response( OPENBB_Roles::save_role( (string) $request['key'], self::role_data( $request ), (string) $request['revision'] ) );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_role( WP_REST_Request $request ) {
		return self::roles_response( OPENBB_Roles::delete_role( (string) $request['key'], (string) $request['revision'] ) );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public function reset_role( WP_REST_Request $request ) {
		return self::roles_response( OPENBB_Roles::reset_role( (string) $request['key'], (string) $request['revision'] ) );
	}

	/**
	 * @return WP_REST_Response|WP_Error
	 */
	public function reset_roles( WP_REST_Request $request ) {
		return self::roles_response( OPENBB_Roles::reset_all( (string) $request['revision'] ) );
	}

	private static function role_data( WP_REST_Request $request ): array {
		return array(
			'label' => $request['label'],
			'caps'  => $request['caps'],
		);
	}

	/**
	 * @param array|WP_Error $result
	 * @return WP_REST_Response|WP_Error
	 */
	private static function roles_response( $result, int $status = 200 ) {
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$response = rest_ensure_response( $result );
		$response->set_status( $status );

		return $response;
	}

	public function get_profile_fields(): WP_REST_Response {
		return rest_ensure_response( self::prepare_profile_fields( OPENBB_Profile_Fields::get_schema() ) );
	}

	/**
	 * Replaces the whole field list; 409 if someone saved since `revision`.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_profile_fields( WP_REST_Request $request ) {
		$schema = OPENBB_Profile_Fields::save_schema( (array) $request['fields'], (int) $request['revision'] );

		return is_wp_error( $schema ) ? $schema : rest_ensure_response( self::prepare_profile_fields( $schema ) );
	}

	/**
	 * Deletes an archived field and its values; the confirmation is the field key.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function purge_profile_field( WP_REST_Request $request ) {
		$key = (string) $request['key'];
		if ( $key !== $request->get_param( 'confirmation' ) ) {
			return self::invalid(
				/* translators: %s: the field key. */
				sprintf( __( 'Type %s to confirm.', 'open-bulk-buying' ), $key ),
				'openbb_purge_unconfirmed'
			);
		}

		$schema = OPENBB_Profile_Fields::purge_field( $key );

		return is_wp_error( $schema ) ? $schema : rest_ensure_response( self::prepare_profile_fields( $schema ) );
	}

	/**
	 * The schema plus the keys the editor must avoid when it suggests a key.
	 */
	private static function prepare_profile_fields( array $schema ): array {
		$schema['reserved_keys'] = OPENBB_Profile_Fields::reserved_keys();

		return $schema;
	}

	private static function prepare_settings(): array {
		return array(
			'test_mode' => OPENBB_Maintenance::is_test_mode(),
			'general'   => OPENBB_Settings::get_general(),
			// The secret itself is never sent back.
			'captcha'   => array(
				'secret_set'           => '' !== OPENBB_Captcha::secret(),
				'secret_from_constant' => OPENBB_Captcha::secret_from_constant(),
			),
		);
	}

	private static function with_status( WP_Error $error, int $status ): WP_Error {
		$data = $error->get_error_data();
		if ( ! is_array( $data ) || ! isset( $data['status'] ) ) {
			$error->add_data( array_merge( is_array( $data ) ? $data : array(), array( 'status' => $status ) ) );
		}

		return $error;
	}
}
