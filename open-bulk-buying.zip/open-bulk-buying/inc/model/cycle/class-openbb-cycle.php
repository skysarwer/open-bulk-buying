<?php
/**
 * Cycle record.
 *
 * @package Open_Bulk_Buying
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OPENBB_Cycle extends OPENBB_Entity {

	const STATUS_SETUP        = 'setup';
	const STATUS_ORDERING     = 'ordering';
	const STATUS_PROCESSING   = 'processing';
	const STATUS_DISTRIBUTION = 'distribution';
	const STATUS_COMPLETE     = 'complete';

	/**
	 * Stages reserving committed orders before hold deadlines are frozen at completion.
	 * Staff can submit orders in setup; several cycles may be active at once.
	 */
	const ACTIVE_STATUSES = array( self::STATUS_SETUP, self::STATUS_ORDERING, self::STATUS_PROCESSING, self::STATUS_DISTRIBUTION );

	public $id                  = 0;
	public $name                = '';
	public $status              = self::STATUS_SETUP;
	public $opens_at            = null;
	public $closes_at           = null;
	public $pickup_opens_at     = null;
	public $pickup_closes_at    = null;
	public $pickup_location     = '';
	public $pickup_instructions = array();
	public $created_at          = null;
	public $updated_at          = null;
	public $finalized_at        = null;
	public $finalized_by        = null;
	public $unpaid_hold_until   = null;
	public $prepaid_hold_until  = null;
	public $cleanup_locked_at   = null;

	protected function cast(): void {
		$this->id                  = (int) $this->id;
		$this->finalized_by        = self::nullable_int( $this->finalized_by );
		$this->pickup_location     = (string) $this->pickup_location;
		$this->pickup_instructions = openbb_normalize_localized( self::decode_json( $this->pickup_instructions ) );
	}

	public function save(): bool {
		global $wpdb;

		$now = current_time( 'mysql', true );
		if ( ! $this->created_at ) {
			$this->created_at = $now;
		}
		$this->updated_at = $now;

		$instructions = wp_json_encode( $this->pickup_instructions );
		if ( false === $instructions ) {
			return false;
		}

		return $this->save_row(
			$wpdb->openbb_cycles,
			array(
				'name'                => $this->name,
				'status'              => $this->status,
				'opens_at'            => $this->opens_at,
				'closes_at'           => $this->closes_at,
				'pickup_opens_at'     => $this->pickup_opens_at,
				'pickup_closes_at'    => $this->pickup_closes_at,
				'pickup_location'     => $this->pickup_location,
				'pickup_instructions' => $instructions,
				'created_at'          => $this->created_at,
				'updated_at'          => $this->updated_at,
				'finalized_at'        => $this->finalized_at,
				'finalized_by'        => $this->finalized_by,
				'unpaid_hold_until'   => $this->unpaid_hold_until,
				'prepaid_hold_until'  => $this->prepaid_hold_until,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);
	}

	/**
	 * Cycles with orders are retained as history unless the caller is explicitly
	 * authorized to force-delete them and their dependent order records.
	 *
	 * @param bool $force Delete associated orders and preserve detached stock history.
	 * @return true|WP_Error
	 */
	public function delete( bool $force = false ) {
		global $wpdb;

		if ( ! $this->id || ! OPENBB_Cycles::get( (int) $this->id ) ) {
			return new WP_Error( 'openbb_cycle_not_found', __( 'This cycle no longer exists.', 'open-bulk-buying' ) );
		}
		$order_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->openbb_orders} WHERE cycle_id = %d", $this->id ) );
		if ( $wpdb->last_error ) {
			return new WP_Error( 'openbb_cycle_delete_failed', __( 'The cycle could not be deleted.', 'open-bulk-buying' ) );
		}
		if ( $order_count > 0 && ! $force ) {
			return new WP_Error( 'openbb_cycle_has_orders', __( 'A cycle with orders cannot be deleted.', 'open-bulk-buying' ) );
		}
		if ( $force ) {
			return $this->delete_with_orders();
		}
		if ( ! $this->delete_row( $wpdb->openbb_cycles ) ) {
			return new WP_Error( 'openbb_cycle_delete_failed', __( 'The cycle could not be deleted.', 'open-bulk-buying' ) );
		}
		$wpdb->delete( $wpdb->openbb_cycle_products, array( 'cycle_id' => $this->id ), array( '%d' ) );

		return true;
	}

	/**
	 * Deletes a cycle and its orders atomically while preserving inventory history.
	 *
	 * @return true|WP_Error
	 */
	private function delete_with_orders() {
		global $wpdb;

		if ( ! OPENBB_Inventory::lock() ) {
			return new WP_Error( 'openbb_busy', __( 'Stock is being updated. Please try again.', 'open-bulk-buying' ), array( 'status' => 503 ) );
		}
		try {
			if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
				return new WP_Error( 'openbb_cycle_delete_failed', __( 'The cycle could not be deleted.', 'open-bulk-buying' ) );
			}

			$orders = $wpdb->prepare( "SELECT id FROM {$wpdb->openbb_orders} WHERE cycle_id = %d", $this->id );
			$moves_detached = false !== $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$wpdb->openbb_stock_moves} SET order_id = NULL, cycle_id = NULL
					WHERE cycle_id = %d OR order_id IN ({$orders})",
					$this->id
				)
			);
			$events_deleted = $moves_detached && false !== $wpdb->query(
				"DELETE FROM {$wpdb->openbb_order_events} WHERE order_id IN ({$orders})"
			);
			$lines_deleted = $events_deleted && false !== $wpdb->query(
				"DELETE FROM {$wpdb->openbb_order_lines} WHERE order_id IN ({$orders})"
			);
			$orders_deleted = $lines_deleted && false !== $wpdb->delete( $wpdb->openbb_orders, array( 'cycle_id' => $this->id ), array( '%d' ) );
			$prep_deleted   = $orders_deleted && false !== $wpdb->delete( $wpdb->openbb_cycle_products, array( 'cycle_id' => $this->id ), array( '%d' ) );
			$cycle_deleted  = $prep_deleted && 1 === $wpdb->delete( $wpdb->openbb_cycles, array( 'id' => $this->id ), array( '%d' ) );
			if ( ! $cycle_deleted ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'openbb_cycle_delete_failed', __( 'The cycle could not be deleted.', 'open-bulk-buying' ) );
			}

			if ( false === $wpdb->query( 'COMMIT' ) ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'openbb_cycle_delete_failed', __( 'The cycle could not be deleted.', 'open-bulk-buying' ) );
			}

			return true;
		} finally {
			OPENBB_Inventory::unlock();
		}
	}

	/**
	 * Checks the cycle's own rules before saving: a name, dates in order, an
	 * ordering window before leaving setup, and no overlap with another upcoming
	 * or open ordering window (members order from one cycle at a time).
	 *
	 * @return true|WP_Error
	 */
	public function validate() {
		global $wpdb;

		if ( '' === trim( $this->name ) ) {
			return self::invalid( __( 'Enter a cycle name.', 'open-bulk-buying' ) );
		}
		$statuses = array( self::STATUS_SETUP, self::STATUS_ORDERING, self::STATUS_PROCESSING, self::STATUS_DISTRIBUTION, self::STATUS_COMPLETE );
		if ( ! in_array( $this->status, $statuses, true ) ) {
			return self::invalid( __( 'Choose a valid cycle status.', 'open-bulk-buying' ) );
		}
		if ( $this->opens_at && $this->closes_at && strtotime( $this->closes_at ) <= strtotime( $this->opens_at ) ) {
			return self::invalid( __( 'Ordering must close after it opens.', 'open-bulk-buying' ) );
		}
		if ( $this->pickup_opens_at && $this->pickup_closes_at && strtotime( $this->pickup_closes_at ) <= strtotime( $this->pickup_opens_at ) ) {
			return self::invalid( __( 'Pickup must end after it starts.', 'open-bulk-buying' ) );
		}
		if ( self::STATUS_SETUP !== $this->status && ( ! $this->opens_at || ! $this->closes_at ) ) {
			return self::invalid( __( 'Set when ordering opens and closes before opening the cycle.', 'open-bulk-buying' ) );
		}

		if ( $this->opens_at && $this->closes_at && in_array( $this->status, array( self::STATUS_SETUP, self::STATUS_ORDERING ), true ) ) {
			$overlap = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT name FROM {$wpdb->openbb_cycles}
					WHERE id != %d AND status IN (%s, %s)
						AND opens_at IS NOT NULL AND closes_at IS NOT NULL
						AND opens_at < %s AND closes_at > %s
					LIMIT 1",
					(int) $this->id,
					self::STATUS_SETUP,
					self::STATUS_ORDERING,
					$this->closes_at,
					$this->opens_at
				)
			);
			if ( null !== $overlap ) {
				return new WP_Error(
					'openbb_cycle_overlap',
					/* translators: %s: name of the other cycle. */
					sprintf( __( 'This ordering window overlaps with "%s".', 'open-bulk-buying' ), $overlap ),
					array( 'status' => 409 )
				);
			}
		}

		return true;
	}

	/**
	 * Translated status labels in lifecycle order. Only call from UI code.
	 */
	public static function status_labels(): array {
		return array(
			self::STATUS_SETUP        => __( 'Setup', 'open-bulk-buying' ),
			self::STATUS_ORDERING     => __( 'Ordering', 'open-bulk-buying' ),
			self::STATUS_PROCESSING   => __( 'Processing', 'open-bulk-buying' ),
			self::STATUS_DISTRIBUTION => __( 'Distribution', 'open-bulk-buying' ),
			self::STATUS_COMPLETE     => __( 'Complete', 'open-bulk-buying' ),
		);
	}

	public function is_active(): bool {
		return in_array( $this->status, self::ACTIVE_STATUSES, true );
	}

	public function allows_preparation_cleanup(): bool {
		return self::STATUS_SETUP === $this->status && null === $this->cleanup_locked_at
			&& OPENBB_Installer::DB_VERSION === get_option( OPENBB_Installer::DB_VERSION_OPTION );
	}

	public function hold_until( string $order_status ): ?string {
		return $this->{self::hold_field( $order_status )};
	}

	public static function hold_field( string $order_status ): string {
		return OPENBB_Order::STATUS_PREPAID === $order_status ? 'prepaid_hold_until' : 'unpaid_hold_until';
	}

	/**
	 * Whether members can submit or edit orders at $timestamp (default: now).
	 */
	public function accepts_orders( ?int $timestamp = null ): bool {
		if ( self::STATUS_ORDERING !== $this->status || ! $this->opens_at || ! $this->closes_at ) {
			return false;
		}

		$timestamp = $timestamp ?? time();

		return $timestamp >= strtotime( $this->opens_at . ' UTC' )
			&& $timestamp < strtotime( $this->closes_at . ' UTC' );
	}

	/**
	 * Whether $timestamp (default: now) falls within the scheduled pickup, whatever the stage.
	 */
	public function in_pickup_window( ?int $timestamp = null ): bool {
		if ( ! $this->pickup_opens_at || ! $this->pickup_closes_at ) {
			return false;
		}

		$timestamp = $timestamp ?? time();

		return $timestamp >= strtotime( $this->pickup_opens_at . ' UTC' )
			&& $timestamp < strtotime( $this->pickup_closes_at . ' UTC' );
	}

	/**
	 * The stage the cycle's dates say it should have reached by $timestamp (default: now),
	 * or '' if it is on schedule. Stages are only ever changed by staff; this is a reminder.
	 */
	public function due_stage( ?int $timestamp = null ): string {
		$next = array(
			self::STATUS_SETUP        => array( 'opens_at', self::STATUS_ORDERING ),
			self::STATUS_ORDERING     => array( 'closes_at', self::STATUS_PROCESSING ),
			self::STATUS_PROCESSING   => array( 'pickup_opens_at', self::STATUS_DISTRIBUTION ),
			self::STATUS_DISTRIBUTION => array( 'pickup_closes_at', self::STATUS_COMPLETE ),
		);
		if ( ! isset( $next[ $this->status ] ) ) {
			return '';
		}
		list( $field, $stage ) = $next[ $this->status ];

		return $this->$field && ( $timestamp ?? time() ) >= strtotime( $this->$field . ' UTC' ) ? $stage : '';
	}

	public function get_pickup_instructions( ?string $language = null ): string {
		return openbb_localized( $this->pickup_instructions, $language );
	}

	/**
	 * The pickup window in the current locale and site timezone, or '' when unset.
	 */
	public function pickup_window(): string {
		if ( ! $this->pickup_opens_at || ! $this->pickup_closes_at ) {
			return '';
		}
		$opens    = strtotime( $this->pickup_opens_at . ' UTC' );
		$close    = strtotime( $this->pickup_closes_at . ' UTC' );
		$date     = get_option( 'date_format' );
		$time     = get_option( 'time_format' );
		$same_day = wp_date( 'Y-m-d', $opens ) === wp_date( 'Y-m-d', $close );

		return $same_day
			/* translators: 1: date, 2: start time, 3: end time. */
			? sprintf( __( '%1$s, %2$s–%3$s', 'open-bulk-buying' ), wp_date( $date, $opens ), wp_date( $time, $opens ), wp_date( $time, $close ) )
			/* translators: 1: start date and time, 2: end date and time. */
			: sprintf( __( '%1$s to %2$s', 'open-bulk-buying' ), wp_date( $date . ' ' . $time, $opens ), wp_date( $date . ' ' . $time, $close ) );
	}

	private static function invalid( string $message ): WP_Error {
		return new WP_Error( 'openbb_invalid_cycle', $message, array( 'status' => 400 ) );
	}
}
